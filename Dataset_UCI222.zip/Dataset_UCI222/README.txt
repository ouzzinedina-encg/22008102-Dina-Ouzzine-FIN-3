Dataset utilisé dans le projet : Bank Marketing (UCI, jeu n° 222)
Fichier de données : bank-full.csv
Format : CSV séparé par des points-virgules (;)
Taille : 45 211 observations et 17 colonnes (16 variables d'entrée + variable cible y).
Source officielle : https://archive.ics.uci.edu/dataset/222/bank+marketing
Licence : Creative Commons Attribution 4.0 International (CC BY 4.0)
Référence : Moro, S., Rita, P. & Cortez, P. (2014). Bank Marketing. UCI Machine Learning Repository. DOI: 10.24432/C5K306.
